document.addEventListener("DOMContentLoaded", function () {
  const taskInput = document.getElementById("taskInput");
  const dateInput = document.getElementById("dateInput");
  const addButton = document.getElementById("addButton");
  const taskTable = document.getElementById("taskTable");

  addButton.addEventListener("click", function () {
    const task = taskInput.value.trim();
    const dueDate = dateInput.value;

    if (!task || !dueDate) return;

    const row = document.createElement("tr");

    // Checkbox cell
    const checkCell = document.createElement("td");
    checkCell.className = "checkbox-cell";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkCell.appendChild(checkbox);
    row.appendChild(checkCell);

    // Task cell
    const taskCell = document.createElement("td");
    taskCell.textContent = task;
    row.appendChild(taskCell);

    // Date cell
    const dateCell = document.createElement("td");
    dateCell.textContent = dueDate;
    row.appendChild(dateCell);

    // Check for overdue
    const today = new Date().toISOString().split("T")[0];
    if (dueDate < today) {
      dateCell.classList.add("overdue");
    }

    // Mark as done
    checkbox.addEventListener("change", function () {
      if (checkbox.checked) {
        taskCell.classList.add("done");
        dateCell.classList.add("done");
      } else {
        taskCell.classList.remove("done");
        dateCell.classList.remove("done");
      }
    });

    taskTable.appendChild(row);
    taskInput.value = "";
    dateInput.value = "";
  });
});